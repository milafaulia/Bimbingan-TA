<!-- add new calendar event modal -->

<script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js" type="text/javascript"></script>

<script src="<?php echo base_url('assets/adminlte/js/jquery-ui.core.js') ?>"></script>
<!-- DATA TABES SCRIPT -->
<script src="<?= base_url('assets/adminlte/js/plugins/datatables/jquery.dataTables.js')?>" type="text/javascript"></script>
        <script src="<?= base_url('assets/adminlte/js/plugins/datatables/dataTables.bootstrap.js')?>" type="text/javascript"></script>
<!-- Morris.js charts -->
<script src="<?php echo base_url() ?>assets/adminlte/js/plugins/morris/morris.min.js"></script>
 <!-- Morris.js charts -->
        <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>

<!-- Sparkline -->
<script src="<?php echo base_url() ?>assets/adminlte/js/plugins/sparkline/jquery.sparkline.min.js"></script>
<!-- jvectormap -->
<script src="<?php echo base_url() ?>assets/adminlte/js/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="<?php echo base_url() ?>assets/adminlte/js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>

<!-- jQuery Knob Chart -->
<script src="<?php echo base_url() ?>assets/adminlte/js/plugins/jqueryKnob/jquery.knob.js"></script>

<!-- daterangepicker -->
<script src="<?php echo base_url() ?>assets/adminlte/js/plugins/daterangepicker/daterangepicker.js"></script>
<!-- datepicker -->
<script src="<?php echo base_url() ?>assets/adminlte/js/plugins/datepicker/bootstrap-datepicker.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="<?php echo base_url() ?>assets/adminlte/js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<!-- iCheck -->
<script src="<?php echo base_url() ?>assets/adminlte/js/plugins/iCheck/icheck.min.js"></script>

<!-- AdminLTE App -->
<script src="<?php echo base_url() ?>assets/adminlte/js/AdminLTE/app.js"></script>>
<script type="text/javascript">
            $(function() {
                $("#table").dataTable();
            });
        </script>
</body>
</html>
